#define TWI_SCL_LOW   P5OUT &= ~(1<<2)
#define TWI_SCL_HIGH  P5OUT |= (1<<2)
#define TWI_SDA_LOW   P5OUT &= ~(1<<3)
#define TWI_SDA_HIGH  P5OUT |= (1<<3)
#define TWI_IN  P5DIR &= ~(1<<3)
#define TWI_OUT P5DIR |= (1<<3)
#define TWI_SDA_IN    ((P5IN >> 3) & 0x01)        //Read SDA
#define short_delay 50

static void delay(unsigned int n)
{
  for(unsigned int i=0;i<=n;i++);
}


void twi_init()
{
  P5OUT |= 0x00;
  P5DIR |= 0x0c;
  delay(short_delay);
  TWI_SCL_HIGH;
  delay(short_delay);
  TWI_SDA_HIGH;
  delay(short_delay);
}

void twi_start(void)
{
  TWI_SDA_HIGH;
  delay(short_delay);
  TWI_SCL_HIGH;
  delay(short_delay);
  TWI_SDA_LOW;
  delay(short_delay);
  TWI_SCL_LOW;
  delay(short_delay);
}

void twi_stop(void)
{
  TWI_SDA_LOW;
  delay(short_delay);
  TWI_SCL_HIGH;
  delay(short_delay);
  TWI_SDA_HIGH;
  delay(short_delay);
  
}

void twi_ack(void)
{
  TWI_SCL_LOW;
  delay(short_delay);
  TWI_OUT;
  TWI_SDA_LOW;
  TWI_SCL_HIGH;
  delay(short_delay);
  TWI_SCL_LOW;
}

void twi_check_ack(void)
{
  unsigned char i = 0;
  TWI_SDA_LOW;
  TWI_IN;  
  TWI_SCL_HIGH;
  delay(short_delay);
  while ((TWI_SDA_IN == 0x01 /*sda==1*/) && (i < 255)/*���Է���,���Բ�Ҫ*/)
  {
    i++;
  }
  TWI_OUT;
  TWI_SCL_LOW;
  delay(short_delay);
}

void twi_send_byte(unsigned char data)
{
  unsigned char i;
  for (i=0; i<8; i++)
  {
    TWI_SCL_LOW;
    delay(short_delay);
    if (((data >> 7) & 0x01) == 0x01)
    {
      TWI_SDA_HIGH;
    }
    else
    {
      TWI_SDA_LOW;
    }
    delay(short_delay);
    TWI_SCL_HIGH;
    data = data << 1;
    delay(short_delay);
  }
  TWI_SCL_LOW;
  TWI_SDA_LOW;
  delay(short_delay);

}

unsigned char twi_get_byte(void)
{
  unsigned char i;
  unsigned char TempBit  = 0;
  unsigned char TempData = 0;
  TWI_SCL_LOW;
  TWI_SDA_LOW;
  TWI_IN;
  delay(short_delay);
  for (i=0; i<8; i++)
  {
    delay(short_delay);
    TWI_SCL_HIGH;
    delay(short_delay);
    if (TWI_SDA_IN == 0x01 /*sda==1*/)
    {
      TempBit = 1;
    }
    else
    {
      TempBit = 0;
    }
    TempData = (TempData << 1) | TempBit;
    TWI_SCL_LOW;
  }
  TWI_OUT;
  delay(short_delay);
  return(TempData);
}

unsigned char twi_read(unsigned char id,unsigned char address)
{
   unsigned char data;
  id = id << 1;
  twi_start();
  twi_send_byte(id);
  twi_check_ack();
  twi_send_byte(address);
  twi_check_ack();
  id = id + 1;
  twi_start();
  twi_send_byte(id);
  twi_check_ack();  
  data = twi_get_byte();
  twi_stop();
  delay(1000);
  return(data);
}

void twi_write(unsigned char id,unsigned char address,unsigned char data)
{
  id = id << 1;
  twi_start();
  twi_send_byte(id);
  twi_check_ack();
  twi_send_byte(address);
  twi_check_ack();
  twi_send_byte(data);  
  twi_check_ack();
  twi_stop();  
  delay(1000);
}

unsigned int twi_read_word(unsigned char id,unsigned char address)
{
   unsigned int data,data1;
  id = id << 1;
  twi_start();
  twi_send_byte(id);
  twi_check_ack();
  twi_send_byte(address);
  twi_check_ack();
  id = id + 1;
  twi_start();
  twi_send_byte(id);
  twi_check_ack();  
  data = twi_get_byte();
  twi_ack();
  data1 = twi_get_byte(); 
  twi_ack();  
  twi_stop();
  delay(1000);
  data = (data<<8) + data1;
  return(data);
}

void twi_write_word (unsigned char id,unsigned char address,unsigned int data)
{
  unsigned char data0;
  data0 = data & 0xff;
  data = (data>>8);
  id = id << 1;
  twi_start();
  twi_send_byte(id);
  twi_check_ack();
  twi_send_byte(address);
  twi_check_ack();
  twi_send_byte(data);  
  twi_check_ack();
  twi_send_byte(data0);
  twi_check_ack();  
  twi_stop();  
  delay(1000);
}