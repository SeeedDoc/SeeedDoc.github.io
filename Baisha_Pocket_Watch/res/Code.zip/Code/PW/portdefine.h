#define H1_HIGH {P6OUT |=(1<<1);P6DIR |= (1<<1);}
#define H1_LOW {P6OUT &=~(1<<1);P6DIR |= (1<<1);}
#define H1_OFF {P6OUT |=(1<<1);P6DIR &=~(1<<1);}

#define H2_HIGH {P6OUT |=(1<<0);P6DIR |= (1<<0);}
#define H2_LOW {P6OUT &=~(1<<0);P6DIR |= (1<<0);}
#define H2_OFF {P6OUT |=(1<<0);P6DIR &=~(1<<0);}

#define H3_HIGH {P1OUT |=(1<<5);P1DIR |= (1<<5);}
#define H3_LOW {P1OUT &=~(1<<5);P1DIR |= (1<<5);}
#define H3_OFF {P1OUT |=(1<<5);P1DIR &=~(1<<5);}

#define H4_HIGH {P1OUT |=(1<<6);P1DIR |= (1<<6);}
#define H4_LOW  {P1OUT &=~(1<<6);P1DIR |= (1<<6);}
#define H4_OFF  {P1OUT |=(1<<6);P1DIR &=~(1<<6);}
                                
#define H5_HIGH {P3OUT |=(1<<1);P3DIR |= (1<<1);}
#define H5_LOW  {P3OUT &=~(1<<1);P3DIR |= (1<<1);}
#define H5_OFF  {P3OUT |=(1<<1);P3DIR &=~(1<<1);}
                                
#define H6_HIGH {P3OUT |=(1<<2);P3DIR |= (1<<2);}
#define H6_LOW  {P3OUT &=~(1<<2);P3DIR |= (1<<2);}
#define H6_OFF  {P3OUT |=(1<<2);P3DIR &=~(1<<2);}
                                
#define H7_HIGH {P3OUT |=(1<<3);P3DIR |= (1<<3);}
#define H7_LOW  {P3OUT &=~(1<<3);P3DIR |= (1<<3);}
#define H7_OFF  {P3OUT |=(1<<3);P3DIR &=~(1<<3);}
                                
#define H8_HIGH {P4OUT |=(1<<5);P4DIR |= (1<<5);}
#define H8_LOW  {P4OUT &=~(1<<5);P4DIR |= (1<<5);}
#define H8_OFF  {P4OUT |=(1<<5);P4DIR &=~(1<<5);}
                                
#define H9_HIGH {P4OUT |=(1<<6);P4DIR |= (1<<6);}
#define H9_LOW  {P4OUT &=~(1<<6);P4DIR |= (1<<6);}
#define H9_OFF  {P4OUT |=(1<<6);P4DIR &=~(1<<6);}

#define H10_HIGH {P4OUT |=(1<<7);P4DIR |= (1<<7);}
#define H10_LOW  {P4OUT &=~(1<<7);P4DIR |= (1<<7);}
#define H10_OFF  {P4OUT |=(1<<7);P4DIR &=~(1<<7);}
                                 
#define H11_HIGH {P6OUT |=(1<<4);P6DIR |= (1<<4);}
#define H11_LOW  {P6OUT &=~(1<<4);P6DIR |= (1<<4);}
#define H11_OFF  {P6OUT |=(1<<4);P6DIR &=~(1<<4);}
                                 
#define H12_HIGH {P6OUT |=(1<<2);P6DIR |= (1<<2);}
#define H12_LOW  {P6OUT &=~(1<<2);P6DIR |= (1<<2);}
#define H12_OFF  {P6OUT |=(1<<2);P6DIR &=~(1<<2);}



void switch_hs(unsigned int h_line)
{
    switch(h_line)
  {
  case 0:
    {
      H7_HIGH;
      break;
    }
  case 1:
    { 
      H8_HIGH;
      break;
    }
  case 2:
    {
      H9_HIGH;
      break;
    }
  case 3:
    {
      H10_HIGH;
      break;
    }
  case 4:
    { 
      H11_HIGH;
      break;
    }
  case 5:
    {
      H12_HIGH;
      break;
    }
  case 6:
    {
      H1_HIGH;
      break;
    }
  case 7:
    { 
      H2_HIGH;
      break;
    }
  case 8:
    {
      H3_HIGH;
      break;
    }
  case 9:
    {
      H4_HIGH;
      break;
    }
  case 10:
    { 
      H5_HIGH;
      break;
    }
  case 11:
    {
      H6_HIGH;
      break;
    }
  }
}

void switch_hm(unsigned int h_line)
{
    switch(h_line)
  {
  case 0:
    {
      H7_LOW;
      break;
    }
  case 1:
    { 
      H8_LOW;
      break;
    }
  case 2:
    {
      H9_LOW;
      break;
    }
  case 3:
    {
      H10_LOW;
      break;
    }
  case 4:
    { 
      H11_LOW;
      break;
    }
  case 5:
    {
      H12_LOW;
      break;
    }
  case 6:
    {
      H1_LOW;
      break;
    }
  case 7:
    { 
      H2_LOW;
      break;
    }
  case 8:
    {
      H3_LOW;
      break;
    }
  case 9:
    {
      H4_LOW;
      break;
    }
  case 10:
    { 
      H5_LOW;
      break;
    }
  case 11:
    {
      H6_LOW;
      break;
    }
  }
}
