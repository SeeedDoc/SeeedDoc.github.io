These are additional experiments written by SparkFun customer Mike Soltys.
