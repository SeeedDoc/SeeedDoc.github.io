
int ledPin =  3;    // The simon board has 4 LEDs on it. 
                    // For this example, we're just going to use one. 
                    // The other LEDs are on pins 3,5,10 and 13.
                    // For fun, try switching "ledPin" to another pin number and see what happens!
                    
int buttonPin =  2; // The simon board has 4 BUTTONS on it. 
                    // For this example, we're just going to use one. 
                    // The other BUTTONS are on pins 2,6,9 and 12.
                    // For fun, try switching "buttonPin" to another pin number and see what happens!
                    
int button_state;   // This variable will be used to "store" the state of the button.
                    // It will allow us to know whether the button is pressed or not.
